# PROJECT_STATE
Fase activa: 2 (núcleo RPG, parcial).

| Componente | Estado |
|---|---|
| rpgcore (XpCurve, PlayerProgress, Stamina) | Compilado y probado (112 comprobaciones) |
| Proyecto Fabric (build.gradle, mod json, workflow) | Escrito, SIN compilar |
| Persistencia (Data Attachments), niveles de mobs, XP por kill, comandos | Escrito, SIN compilar, SIN probar en juego |
| Stamina integrada, maestrías, habilidades, HUD, red, rarezas, config, antiabuso | No implementado |

## Riesgos de compilación conocidos (APIs de 1.21.11 no verificadas contra el código real)
- `Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)`: el sistema de permisos cambió en 1.21.11.
- `Identifier.fromNamespaceAndPath`, `handler.getPlayer()`, `addOrReplacePermanentModifier`,
  plugin Loom `net.fabricmc.fabric-loom-remap`.
Protocolo: pegar el primer error de Actions; se corrige solo ese símbolo.

## Siguiente paso
Build en Actions -> corregir errores -> probar en juego -> Stamina y maestrías (Fase 3).
