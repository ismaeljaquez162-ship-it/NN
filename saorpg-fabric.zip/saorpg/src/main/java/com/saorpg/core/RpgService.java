package com.saorpg.core;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import rpgcore.PlayerProgress;
import rpgcore.XpCurve;

/** Lógica RPG del lado servidor (autoritativa). Usa el núcleo `rpgcore` verificado. */
public final class RpgService {
    public static final XpCurve CURVE = XpCurve.defaults();
    private static final double HP_PER_LEVEL = 0.5; // medio corazón por nivel
    private static final Identifier HP_MODIFIER = Identifier.fromNamespaceAndPath("saorpg", "level_health");

    private RpgService() {}

    public static PlayerProgress progress(ServerPlayer p) {
        RpgData d = p.getAttachedOrCreate(RpgAttachments.PLAYER);
        return new PlayerProgress(CURVE, d.level(), d.xp());
    }

    /** Concede XP; devuelve niveles ganados. Aplica bonificaciones y avisa al jugador. */
    public static int grantXp(ServerPlayer p, long amount) {
        PlayerProgress pr = progress(p);
        int gained = pr.addXp(amount);
        p.setAttached(RpgAttachments.PLAYER, new RpgData(RpgData.CURRENT_VERSION, pr.level(), pr.xpInLevel()));
        if (gained > 0) {
            applyLevelBonuses(p, pr.level());
            p.setHealth(p.getMaxHealth());
            p.sendSystemMessage(Component.literal("¡LEVEL UP! Nivel " + pr.level()));
        }
        actionBar(p, pr);
        return gained;
    }

    /** Modificador estable con ID fijo: addOrReplace evita acumular bonificaciones duplicadas. */
    public static void applyLevelBonuses(ServerPlayer p, int level) {
        AttributeInstance hp = p.getAttribute(Attributes.MAX_HEALTH);
        if (hp == null) return;
        hp.addOrReplacePermanentModifier(new AttributeModifier(
                HP_MODIFIER, (level - 1) * HP_PER_LEVEL, AttributeModifier.Operation.ADD_VALUE));
    }

    public static void actionBar(ServerPlayer p, PlayerProgress pr) {
        String xp = pr.xpNeeded() == 0 ? "MAX" : pr.xpInLevel() + " / " + pr.xpNeeded();
        p.displayClientMessage(Component.literal("LV. " + pr.level() + "  |  XP " + xp), true);
    }
}
