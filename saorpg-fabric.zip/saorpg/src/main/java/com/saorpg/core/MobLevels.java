package com.saorpg.core;

import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** Asignación de nivel a mobs hostiles: tipo + dimensión + variación aleatoria pequeña. Se fija una vez. */
public final class MobLevels {
    private static final Map<String, Integer> BASE = Map.of(
            "zombie", 4, "spider", 7, "skeleton", 12, "creeper", 8, "witch", 14, "enderman", 28,
            "blaze", 30, "wither_skeleton", 40);
    private static final int DEFAULT_BASE = 5;

    private MobLevels() {}

    public static void assignIfMissing(Entity e, ServerLevel world) {
        if (e.getAttached(RpgAttachments.MOB_LEVEL) != null) return;
        String key = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
        int level = BASE.getOrDefault(key, DEFAULT_BASE);
        if (world.dimension() == Level.NETHER) level += 10;
        else if (world.dimension() == Level.END) level += 20;
        level += world.getRandom().nextInt(3); // 0..2
        e.setAttached(RpgAttachments.MOB_LEVEL, level);
    }

    /** XP base por kill: 5 + 2*nivel (placeholder documentado, a balancear). */
    public static long xpReward(int mobLevel) { return 5L + 2L * mobLevel; }
}
