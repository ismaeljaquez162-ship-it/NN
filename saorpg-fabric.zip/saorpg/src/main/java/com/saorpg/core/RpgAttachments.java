package com.saorpg.core;

import com.mojang.serialization.Codec;
import com.saorpg.SaoRpgMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.resources.Identifier;

/** Persistencia mediante Data Attachments de Fabric API (se guarda con el mundo/jugador). */
public final class RpgAttachments {
    public static final AttachmentType<RpgData> PLAYER = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(SaoRpgMod.MOD_ID, "player_data"),
            b -> b.persistent(RpgData.CODEC).copyOnDeath().initializer(RpgData::new));

    public static final AttachmentType<Integer> MOB_LEVEL = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(SaoRpgMod.MOD_ID, "mob_level"),
            b -> b.persistent(Codec.INT));

    private RpgAttachments() {}
    public static void init() { /* fuerza la carga de la clase y el registro */ }
}
