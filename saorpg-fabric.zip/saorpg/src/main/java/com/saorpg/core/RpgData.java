package com.saorpg.core;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** Datos persistentes del jugador. `version` permite migrar el formato en el futuro. */
public record RpgData(int version, int level, long xp) {
    public static final int CURRENT_VERSION = 1;
    public static final Codec<RpgData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("v", CURRENT_VERSION).forGetter(RpgData::version),
            Codec.INT.optionalFieldOf("level", 1).forGetter(RpgData::level),
            Codec.LONG.optionalFieldOf("xp", 0L).forGetter(RpgData::xp)
    ).apply(i, RpgData::new));

    public RpgData() { this(CURRENT_VERSION, 1, 0L); }
}
