package com.saorpg;

import com.mojang.brigadier.arguments.LongArgumentType;
import com.saorpg.core.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Enemy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rpgcore.PlayerProgress;

public class SaoRpgMod implements ModInitializer {
    public static final String MOD_ID = "saorpg";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        RpgAttachments.init();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            PlayerProgress pr = RpgService.progress(p);
            RpgService.applyLevelBonuses(p, pr.level());
            RpgService.actionBar(p, pr);
        });

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof Enemy) MobLevels.assignIfMissing(entity, world);
        });

        // XP una sola vez por muerte válida: AFTER_DEATH se dispara una vez por entidad.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(entity instanceof Enemy)) return;
            if (!(source.getEntity() instanceof ServerPlayer killer)) return;
            Integer lvl = entity.getAttached(RpgAttachments.MOB_LEVEL);
            if (lvl == null) return;
            RpgService.grantXp(killer, MobLevels.xpReward(lvl));
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("rpg")
                .then(Commands.literal("stats").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    PlayerProgress pr = RpgService.progress(p);
                    ctx.getSource().sendSuccess(() -> Component.literal(
                        "Nivel " + pr.level() + " | XP " + pr.xpInLevel() + "/" + pr.xpNeeded()), false);
                    return 1;
                }))
                .then(Commands.literal("admin")
                    .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                    .then(Commands.literal("addxp")
                        .then(Commands.argument("target", EntityArgument.player())
                            .then(Commands.argument("amount", LongArgumentType.longArg(1, 1_000_000_000L))
                                .executes(ctx -> {
                                    ServerPlayer t = EntityArgument.getPlayer(ctx, "target");
                                    long amt = LongArgumentType.getLong(ctx, "amount");
                                    int g = RpgService.grantXp(t, amt);
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                        "+" + amt + " XP a " + t.getName().getString() + " (" + g + " niveles)"), true);
                                    return 1;
                                })))))));

        LOGGER.info("SAO RPG iniciado (curva XP, persistencia, niveles de mobs).");
    }
}
