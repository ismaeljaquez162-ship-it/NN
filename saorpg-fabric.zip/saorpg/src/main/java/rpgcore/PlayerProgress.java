package rpgcore;

/** Estado de progreso RPG de un jugador. Aritmética segura; permite varios niveles por recompensa. */
public final class PlayerProgress {
    private final XpCurve curve; private int level; private long xpInLevel;
    public PlayerProgress(XpCurve curve) { this(curve, 1, 0); }
    public PlayerProgress(XpCurve curve, int level, long xpInLevel) {
        this.curve = curve;
        this.level = Math.max(1, Math.min(level, curve.maxLevel));
        long need = curve.xpToNext(this.level);
        this.xpInLevel = (need == 0) ? 0 : Math.max(0, Math.min(xpInLevel, need - 1));
    }
    public int level() { return level; }
    public long xpInLevel() { return xpInLevel; }
    public long xpNeeded() { return curve.xpToNext(level); }
    /** @return niveles ganados (0 si amount <= 0 o nivel máximo). */
    public int addXp(long amount) {
        if (amount <= 0 || level >= curve.maxLevel) return 0;
        int gained = 0; long remaining = amount;
        while (remaining > 0 && level < curve.maxLevel) {
            long need = curve.xpToNext(level) - xpInLevel;
            if (remaining >= need) { remaining -= need; level++; xpInLevel = 0; gained++; }
            else { xpInLevel += remaining; remaining = 0; }
        }
        return gained;
    }
}
