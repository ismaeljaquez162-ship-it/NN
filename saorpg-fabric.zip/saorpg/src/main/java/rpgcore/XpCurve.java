package rpgcore;

/** Curva de XP configurable: xpParaSubir(n) = round(base * n^exponente). Sin dependencias de Minecraft. */
public final class XpCurve {
    public final long base; public final double exponent; public final int maxLevel;
    public XpCurve(long base, double exponent, int maxLevel) {
        if (base < 1 || exponent < 1.0 || exponent > 3.0 || maxLevel < 1 || maxLevel > 10_000)
            throw new IllegalArgumentException("Configuración de curva inválida");
        this.base = base; this.exponent = exponent; this.maxLevel = maxLevel;
    }
    public static XpCurve defaults() { return new XpCurve(100, 1.6, 100); }
    /** XP necesaria para pasar de `level` a `level+1`. 0 si ya es nivel máximo. */
    public long xpToNext(int level) {
        if (level < 1) throw new IllegalArgumentException("level < 1");
        if (level >= maxLevel) return 0;
        double v = Math.round(base * Math.pow(level, exponent));
        return v >= Long.MAX_VALUE / 4 ? Long.MAX_VALUE / 4 : (long) v;
    }
    public long cumulativeXp(int level) { long t = 0; for (int l = 1; l < level; l++) t += xpToNext(l); return t; }
}
