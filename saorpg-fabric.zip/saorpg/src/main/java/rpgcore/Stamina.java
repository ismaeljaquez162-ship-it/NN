package rpgcore;

/** Energía: consumo por acción, pausa de regeneración y regeneración pasiva (por tick). */
public final class Stamina {
    private final int max, regenDelayTicks; private final double regenPerTick;
    private double current; private int delay;
    public Stamina(int max, double regenPerTick, int regenDelayTicks) {
        if (max < 1 || regenPerTick < 0 || regenDelayTicks < 0) throw new IllegalArgumentException();
        this.max = max; this.regenPerTick = regenPerTick; this.regenDelayTicks = regenDelayTicks; this.current = max;
    }
    public double current() { return current; }
    public boolean exhausted() { return current <= 0; }
    /** Todo o nada: si no alcanza, no consume y devuelve false. */
    public boolean tryConsume(double cost) {
        if (cost < 0 || Double.isNaN(cost) || cost > current) return false;
        current -= cost; delay = regenDelayTicks; return true;
    }
    public void tick() {
        if (delay > 0) { delay--; return; }
        current = Math.min(max, current + regenPerTick);
    }
}
