package rpgcore;

public final class SelfCheck {
    static int ok = 0;
    static void check(boolean c, String msg) { if (!c) throw new AssertionError("FALLA: " + msg); ok++; }
    public static void main(String[] a) {
        XpCurve c = XpCurve.defaults();
        check(c.xpToNext(1) == 100, "nivel 1 -> 100 XP");
        check(c.xpToNext(100) == 0, "nivel máximo no necesita XP");
        for (int l = 1; l < 99; l++) check(c.xpToNext(l + 1) > c.xpToNext(l), "curva creciente en " + l);
        PlayerProgress p = new PlayerProgress(c);
        check(p.addXp(-50) == 0 && p.xpInLevel() == 0, "XP negativa ignorada");
        check(p.addXp(99) == 0 && p.xpInLevel() == 99, "99 XP no sube");
        check(p.addXp(1) == 1 && p.level() == 2 && p.xpInLevel() == 0, "100 XP sube a 2");
        check(p.addXp(c.cumulativeXp(10) - c.cumulativeXp(2)) == 8 && p.level() == 10, "multi-nivel en un solo premio");
        PlayerProgress m = new PlayerProgress(c);
        m.addXp(Long.MAX_VALUE);
        check(m.level() == 100 && m.xpInLevel() == 0, "Long.MAX_VALUE satura en nivel máximo sin overflow");
        check(m.addXp(1000) == 0, "sin ganancia en nivel máximo");
        PlayerProgress bad = new PlayerProgress(c, 5000, -9);
        check(bad.level() == 100 && bad.xpInLevel() == 0, "datos corruptos se sanean");
        Stamina s = new Stamina(100, 1.0, 20);
        check(s.tryConsume(30) && s.current() == 70, "consume 30");
        check(!s.tryConsume(71) && s.current() == 70, "no consume si no alcanza");
        for (int i = 0; i < 20; i++) s.tick();
        check(s.current() == 70, "pausa de regeneración de 20 ticks");
        for (int i = 0; i < 50; i++) s.tick();
        check(s.current() == 100, "regenera hasta el máximo sin pasarse");
        check(!s.tryConsume(Double.NaN) && !s.tryConsume(-5), "rechaza NaN y negativos");
        System.out.println("OK: " + ok + " comprobaciones pasaron\n");
        System.out.println("Nivel | XP para subir | XP acumulada");
        for (int l : new int[]{1, 10, 25, 50, 75, 99})
            System.out.printf("%5d | %13d | %12d%n", l, c.xpToNext(l), c.cumulativeXp(l));
        System.out.printf("Total hasta nivel 100: %d XP%n", c.cumulativeXp(100));
    }
}
