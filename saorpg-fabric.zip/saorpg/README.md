# SAO RPG (Fabric 1.21.11) — v0.1.0

Solo servidor: funciona también con clientes vanilla (sin HUD propio todavía; usa la action bar).

## Cómo obtener el JAR sin pagar nada
1. Crea un repositorio en GitHub y sube esta carpeta (en la web: "Add file > Upload files").
2. Pestaña **Actions** > workflow **build** (arranca solo al subir) > al terminar, descarga el artifact **saorpg-jar**.
3. Si el build falla, copia el primer error y pégamelo en el chat: lo corrijo.
4. Instalar: Minecraft 1.21.11 + Fabric Loader >= 0.18.1 + Fabric API, y el JAR en `mods/`.

## Qué hace hoy
Nivel y XP RPG por jugador (persistente), curva de XP configurable en código, niveles de mobs hostiles
(tipo + dimensión), XP al matar, +0,5 corazón por nivel (modificador estable), `/rpg stats`,
`/rpg admin addxp <jugador> <cantidad>`.

## Estado real
Ver PROJECT_STATE.md.
